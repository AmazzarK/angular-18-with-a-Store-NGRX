export const LOAD_ARTICLES = '[Blog dist] load all articles dist';
export const LOAD_ARTICLES_SUCCESS =
  '[Blog dist] load all articles success dist';
export const LOAD_ARTICLES_FAILURE =
  '[Blog dist] load all articles failure dist';

export const ADD_ARTICLE = '[Blog dist] create article dist';
export const ADD_ARTICLE_SUCCESS = '[Blog dist] create article success dist';
export const ADD_ARTICLE_FAILURE = '[Blog dist] create article failure dist';

export const LOAD_ONE_ARTICLE = '[Blog] load one article';
export const LOAD_ONE_ARTICLE_SUCCESS = '[Blog] load one article success';
export const LOAD_ONE_ARTICLE_FAILURE = '[Blog] load one article failure';

export const UPDATE_ARTICLE = '[Blog dist] update article dist';
export const UPDATE_ARTICLE_SUCCESS = '[Blog dist] update article success dist';
export const UPDATE_ARTICLE_FAILURE = '[Blog dist] update article failure dist';

export const DELETE_ARTICLE = '[Blog dist] delete article dist';
export const DELETE_ARTICLE_SUCCESS = '[Blog dist] delete article success dist';
export const DELETE_ARTICLE_FAILURE = '[Blog dist] delete article failure dist';
