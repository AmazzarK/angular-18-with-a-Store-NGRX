export interface CounterState {
  count: number;
}
