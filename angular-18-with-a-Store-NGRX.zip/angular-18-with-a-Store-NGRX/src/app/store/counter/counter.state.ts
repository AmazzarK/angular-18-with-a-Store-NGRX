import { CounterState } from './counter.model';

export const counterState: CounterState = {
  count: 0,
};
