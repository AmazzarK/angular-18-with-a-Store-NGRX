import { Component } from '@angular/core';

@Component({
  selector: 'app-skeleton-card',
  standalone: true,
  imports: [],
  templateUrl: './skeleton-card.component.html',
  styleUrl: './skeleton-card.component.css'
})
export class SkeletonCardComponent {

}
